package consoleView;

import java.util.Scanner;

public class BangunDatarConsole {
    public static void show() {
        Scanner input = new Scanner(System.in);
        boolean loop = true;
        
        while(loop) {
            System.out.println("*** BANGUN DATAR (2D) ***");
            System.out.println("Menu:");
            System.out.println("[1] Belah Ketupat");
            System.out.println("[2] Jajar Genjang");
            System.out.println("[3] Lingkaran");
            System.out.println("[4] Layang-Layang");
            System.out.println("[5] Persegi");
            System.out.println("[6] Persegi Panjang");
            System.out.println("[7] Segitiga");
            System.out.println("[8] Trapesium");
            System.out.println("[9] Juring Lingkaran");
            System.out.println("[10] Tembereng Lingkaran");
            System.out.println("[11] Kembali");
            System.out.print("Pilih: ");
            int pilihMenu = input.nextInt();

            switch(pilihMenu) {
                case 1:
                    BelahKetupatConsole.show();
                    loop = false;
                    break;
                case 2:
                    JajarGenjangConsole.show();
                    loop = false;
                    break;
                case 3:
                    LingkaranConsole.show();
                    loop = false;
                    break;
                case 4:
                    LayangLayangConsole.show();
                    loop = false;
                    break;
                case 5:
                    PersegiConsole.show();
                    loop = false;
                    break;
                case 6:
                    PersegiPanjangConsole.show();
                    loop = false;
                    break;
                case 7:
                    SegitigaConsole.show();
                    loop = false;
                    break;
                case 8:
                    TrapesiumConsole.show();
                    loop = false;
                    break;
                case 9:
                    JuringLingkaranConsole.show();
                    loop = false;
                    break;
                case 10:
                    TemberengLingkaranConsole.show();
                    loop = false;
                    break;
                case 11:
                    MenuUtamaConsole.show();
                    loop = false;
                    break;
                default:
                    System.out.println("Menu tidak tersedia!");
//                    input.nextLine();
            }
            
        }
    }
}
