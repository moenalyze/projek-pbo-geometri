package projekpbo;

import consoleView.*;
//import gui.BangunDatar;

public class Main {
    public static void main(String[] args) {
//        JuringLingkaranConsole.show();
//        KerucutTerpancungConsole.show();
//        BelahKetupatConsole.show();
//        LimasBelahKetupatConsole.show();
//        PrismaBelahKetupatConsole.show();
        MenuUtamaConsole.show();
//        BolaConsole.show();
//        JajarGenjangConsole.show();
//          PrismaJajarGenjangConsole.show();
//          TabungConsole.show();
//          TemberengLingkaranConsole.show();
        
//        new BangunDatar();

        
        
    }
}
